/*
Copyright 2009-2012 Urban Airship Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE URBAN AIRSHIP INC ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL URBAN AIRSHIP INC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.urbanairship.iap;

import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.content.Context;
import android.content.SharedPreferences;

import com.urbanairship.Logger;
import com.urbanairship.UAirship;

class Receipt {

    private String productId, orderId, signedData, signature;
    private Integer productRevision;
    private Long purchaseTime;
    private String downloadPathString;

    private static final String RECEIPT_STORE = "com.urbanairship.iap.receipts";

    Receipt(String serializedJSONString) {

        try {
            JSONObject o = (JSONObject) new JSONTokener(serializedJSONString).nextValue();

            //free products
            productId = o.getString("productId");
            productRevision = o.getInt("productRevision");

            //paid products -- prefer null if not present
            orderId = o.optString("orderId", null);
            purchaseTime = o.optLong("purchaseTime");

            signedData = o.optString("data", null);
            signature = o.optString("signature", null);

            //download path -- prefer null if not present
            downloadPathString = o.optString("downloadPathString", null);
        }

        catch (JSONException e) {
            Logger.error("Error parsing receipt");
        }
    }

    //convenience constructor for storing stripped-down receipts for free products

    Receipt(Integer theRevision, String theProductId) {
        this(theRevision, theProductId, null, null, null, null, null);
    }

    Receipt(Integer theRevision, String theProductId, String theOrderId,
            Long thePurchaseTime, String data, String sig) {
        this(theRevision, theProductId, theOrderId, thePurchaseTime, data, sig, null);
    }

    Receipt(Integer theRevision, String theProductId, String theOrderId,
            Long thePurchaseTime, String data, String sig, String pathString) {

        //free products
        productId = theProductId;
        productRevision = theRevision;

        //paid products
        orderId = theOrderId;
        purchaseTime = thePurchaseTime;

        signedData = data;
        signature = sig;

        //download path

        downloadPathString = pathString;
    }

    String getProductId() {
        return productId;
    }

    String getOrderId() {
        return orderId;
    }

    String getSignedData() {
        return signedData;
    }

    String getSignature() {
        return signature;
    }

    Integer getProductRevision() {
        return productRevision;
    }

    Long getPurchaseTime() {
        return purchaseTime;
    }

    String getDownloadPathString() {
        return downloadPathString;
    }

    void setProductRevision(Integer revision) {
        productRevision = revision;
    }

    void setDownloadPathString(String pathString) {
        downloadPathString = pathString;
    }

    boolean serialize() {
        JSONObject jsonReceipt = new JSONObject();

        try {
            //free products
            jsonReceipt.put("productRevision", productRevision);
            jsonReceipt.put("productId", productId);

            //paid products
            if(orderId != null)
                jsonReceipt.put("orderId", orderId);
            if(purchaseTime != null)
                jsonReceipt.put("purchaseTime", purchaseTime);
            if(signedData != null)
                jsonReceipt.put("data", signedData);
            if(signature !=null)
                jsonReceipt.put("signature", signature);

            //download path
            if(downloadPathString != null)
                jsonReceipt.put("downloadPathString", downloadPathString);
        }

        catch (JSONException e) {
            Logger.error("error constructing JSON object out of receipt data");
            return false;
        }

        try {
            SharedPreferences prefs = getReceiptStore();

            SharedPreferences.Editor editor = prefs.edit();
            editor.putString(productId, jsonReceipt.toString());
            editor.commit();
        }

        catch (Exception e) {
            Logger.error("error writing receipt");
            return false;
        }

        return true;
    }

    static Receipt fetch(String productId) {

        SharedPreferences prefs = getReceiptStore();
        String jsonString = null;
        Receipt receipt = null;

        try {
            jsonString = prefs.getString(productId, null);
        }

        catch (ClassCastException e) {
            Logger.error("receipt not found for "+productId);
        }

        if (jsonString != null)
            receipt = new Receipt(jsonString);

        return receipt;
    }

    static boolean contains(String productId) {
        return getReceiptStore().contains(productId);
    }

    static boolean hasReceipts() {
        SharedPreferences prefs = getReceiptStore();
        Map<String, ?> values = prefs.getAll();
        return !values.isEmpty();
    }

    static SharedPreferences getReceiptStore() {
        Context appContext = UAirship.shared().getApplicationContext();
        return appContext.getSharedPreferences(RECEIPT_STORE, Context.MODE_PRIVATE);
    }


}
