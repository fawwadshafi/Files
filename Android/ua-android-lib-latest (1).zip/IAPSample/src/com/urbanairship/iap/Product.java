/*
Copyright 2009-2012 Urban Airship Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE URBAN AIRSHIP INC ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL URBAN AIRSHIP INC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.urbanairship.iap;

import java.io.File;
import java.text.DecimalFormat;
import java.util.Observable;
import java.util.Observer;

import org.json.JSONObject;

import com.urbanairship.Logger;

/**
 * Data structure for describing a product.
 *
 */
public class Product implements Comparable<Product> {

    /**
     * Product purchase states.
     */
    public enum Status {

        /**
         * The product has not been purchased.
         */
        UNPURCHASED,

        /**
         * The product has been purchased, but is still pending successful download.
         */
        PURCHASED,

        /**
         * The product is awaiting receipt verification.
         */
        WAITING,

        /**
         * The product is currently downloading.
         */
        DOWNLOADING,

        /**
         * The product is installed, but an update is available.
         */
        UPDATE,

        /**
         * The product has been purchased and is installed.
         */
        INSTALLED
    };

    //TODO: the sort method should probably used bean-style getters to access data so that we
    //can add sort options without changing visibility or breaking existing encapsulation
    //these are package protected instead of private so Inventory can sort by them using reflection
    String identifier;
    String title;
    String price;

    private String description;
    private boolean isFree;
    private int revision;
    private double fileSize;

    private String previewURLString;
    private String iconURLString;
    private String downloadURLString;

    private File downloadPath;

    private Status status;

    private ProductObservable notifier;

    private class ProductObservable extends Observable {
        public void notifyObservers(Object o) {
            setChanged();
            super.notifyObservers(o);
        }
    }

    Product() {
        setStatus(Status.PURCHASED);
    }

    /**
     * Product constructor.  Typically you shouldn't try to create a product
     * manually, creation is handled by Inventory
     * 
     * @param jsonObject
     */
    Product(JSONObject jsonObject) {
        this.identifier = jsonObject.optString("product_id");
        this.title = jsonObject.optString("name");
        this.description = jsonObject.optString("description");
        this.price = jsonObject.optString("price", "");
        this.isFree = jsonObject.optBoolean("free");
        if(isFree) this.price = "FREE";
        this.revision = jsonObject.optInt("current_revision", 1);
        this.fileSize = jsonObject.optDouble("file_size", 0);
        this.previewURLString = jsonObject.optString("preview_url");
        this.iconURLString = jsonObject.optString("icon_url");
        this.downloadURLString = jsonObject.optString("download_url");

        //do we have an existing receipt for this product?

        if (Receipt.contains(identifier)) {
            Logger.info("found purchase receipt for "+identifier);
            Receipt receipt = Receipt.fetch(identifier);

            //if there is a newer product revision than the one previously purchased, it's ready to be updated
            if(receipt.getProductRevision() < revision) {
                Logger.info("setting status to UPDATE for "+identifier);
                status = Status.UPDATE;
            }
            //otherwise...
            else {
                //if it's in the pending products list
                if (IAPManager.shared().getDownloadManager().hasPendingProduct(identifier)) {
                    Logger.info(identifier+" is pending");
                    Product existing = IAPManager.shared().getInventory().getProduct(identifier);
                    if (existing != null) {
                        //we've already loaded the inventory, copy the old status
                        status = existing.status;
                        Logger.info(identifier+" has existing status, copying");
                    }
                    else {
                        //otherwise we can assume it's in the "purchased" state
                        Logger.info("setting status to PURCHASED for "+identifier);
                        status = Status.PURCHASED;
                    }
                }
                //there's a receipt and it's not marked pending, so we can assume it's been successfully installed
                else {
                    status = Status.INSTALLED;
                    Logger.info("setting status to INSTALLED for "+identifier);
                }
            }

            //set the full download path, if available
            String downloadPathString = receipt.getDownloadPathString();
            if (downloadPathString != null) {
                this.downloadPath = new File(downloadPathString);
                Logger.info("Download path for "+title+": "+downloadPath);
            }
            else {
                Logger.info("No download path found for "+title);
            }

        }

        //no receipt on disk, assume the product hasn't been purchased before

        else {
            status = Status.UNPURCHASED;
            Logger.info("no receipt found for "+identifier+", setting status to UNPURCHASED");
        }

        notifier = new ProductObservable();
    }

    /**
     * Adds an observer to be notified with the product when its status changes.
     * @param o An object implementing Observer.
     */
    public void addObserver(Observer o) {
        notifier.addObserver(o);
    }

    /**
     * Deletes an observer.
     * @param o An object implementing Observer.
     */
    public void deleteObserver(Observer o) {
        notifier.deleteObserver(o);
    }

    /**
     * Returns the product's icon URL.
     * @return The icon's URL String.
     */
    public String getIconURLString() {
        return iconURLString;
    }

    /**
     * Returns the product's title.
     * @return The product's title String.
     */
    public String getTitle() {
        return title;
    }

    /**
     * Returns the product's description.
     * @return The product's description String.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Returns the product's revision number.
     * @return The product's revision number.
     */
    public int getRevision() {
        return revision;
    }

    /**
     * Returns the product's file size.
     * @return The file size in bytes.
     */
    public double getFileSize() {
        return fileSize;
    }

    /**
     * Returns the product's file size as a human readable string.
     * @return The product's file size as a human readable string.
     */
    public String getHumanReadableFileSize() {

        double bytes, kiloBytes, megaBytes, result;

        bytes = getFileSize();
        kiloBytes = bytes/1000;
        megaBytes = bytes/1000000;

        String suffix;

        if (bytes < 1000) {
            result = bytes;
            suffix = "Bytes";
        }

        else if (kiloBytes >= 1 && kiloBytes < 1000) {
            result = kiloBytes;
            suffix = "KB";
        }

        else {
            result = megaBytes;
            suffix = "MB";
        }

        DecimalFormat formatter = new DecimalFormat("#0.0");

        return formatter.format(result)+suffix;
    }

    /**
     * Returns the product's preview image URL.
     * @return The product's preview image URL as a String.
     */
    public String getPreviewURLString(){
        return previewURLString;
    }

    /**
     * Tests whether the product is free.
     * @return <code>true</code> if the product is free, <code>false</code> otherwise.
     */
    public boolean isFree() {
        return isFree;
    }

    /**
     * Returns the product's price.
     * @return The product's price as a String.
     */
    public String getPrice() {
        return price;
    }

    /**
     * Returns the product's identifier.
     * @return The product's identifier String.
     */
    public String getIdentifier() {
        return identifier;
    }

    /**
     * Sets the product's status.
     * @param status A {@link com.urbanairship.iap.Product.Status} enum.
     */
    void setStatus(Status status) {
        this.status = status;
        notifier.notifyObservers(this);
    }

    /**
     * Returns the product's status.
     * @return A {@link com.urbanairship.iap.Product.Status} enum.
     */
    public Status getStatus() {
        return status;
    }

    /**
     * Returns the product's download URL.
     * @return The product's download URL String.
     */
    public String getDownloadURLString() {
        return downloadURLString;
    }

    /**
     * Returns the product's download path on disk.
     * @return The product's download path String, null if not installed.
     */
    public File getDownloadPath() {
        return downloadPath;
    }

    void setDownloadPath(File path) {
        this.downloadPath = path;
    }

    @Override
    public int compareTo(Product p) {
        return this.getTitle().compareTo(p.getTitle());
    }
}
