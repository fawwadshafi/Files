/*
Copyright 2009-2012 Urban Airship Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE URBAN AIRSHIP INC ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL URBAN AIRSHIP INC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.urbanairship.iap;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;

import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;

import com.urbanairship.Logger;
import com.urbanairship.UAirship;
import com.urbanairship.iap.PurchaseNotificationInfo.NotificationType;
import com.urbanairship.restclient.AppAuthenticatedRequest;
import com.urbanairship.restclient.AsyncHandler;
import com.urbanairship.restclient.Request;
import com.urbanairship.restclient.RequestQueue;
import com.urbanairship.restclient.Response;
import com.urbanairship.util.UnzipperTask;

/**
 * Used by IAP to handle and keep track of product downloads.
 *
 */
public class DownloadManager {

    static final String PENDING_PRODUCTS_FILE = "com.urbanairship.iap.pending_products";
    static final int MAX_TRIES = 3;

    private InventoryObserver inventoryObserver;
    private HashMap<String, Integer> tries;
    private RequestQueue queue;
    private NotificationController notificationController;

    DownloadManager() {
        inventoryObserver = new InventoryObserver();
        tries = new HashMap<String, Integer>(); //product id --> download attempts
        queue = new RequestQueue();
        notificationController = new NotificationController();
        IAPManager.shared().getInventory().addObserver(inventoryObserver);
    }

    SharedPreferences getPendingProducts() {
        Context appContext = UAirship.shared().getApplicationContext();
        return appContext.getSharedPreferences(PENDING_PRODUCTS_FILE, Context.MODE_PRIVATE);
    }

    /**
     * Indicates whether a product download is still pending.
     * @param productId The product's identifier string.
     * @return A boolean indicating the product's pending status
     */
    public boolean hasPendingProduct(String productId) {
        return getPendingProducts().contains(productId);
    }

    /**
     * Initiates the download process for a product, starting with receipt verification.
     * @param product The product being downloaded.
     */
    public void downloadIfValid(Product product) {

        String id = product.getIdentifier();

        if (!hasPendingProduct(id))
            addPendingProduct(id);

        verify(product);
    }

    private void addPendingProduct(String productId) {
        SharedPreferences.Editor editor = getPendingProducts().edit();
        editor.putBoolean(productId, true);
        editor.commit();
    }

    private void removePendingProduct(String productId) {
        SharedPreferences.Editor editor = getPendingProducts().edit();
        editor.remove(productId);
        editor.commit();
    }

    private void resumePendingProducts() {

        Logger.verbose("resumePendingProducts");

        SharedPreferences pendingProducts = getPendingProducts();

        Map<String, ?> values = pendingProducts.getAll();

        for (Map.Entry<String, ?> entry : values.entrySet()) {

            String id = entry.getKey();
            Product product = IAPManager.shared().getInventory().getProduct(id);
            String title = product.getTitle();

            Product.Status status = product.getStatus();

            //download it, as long as that's not currently happening
            if (status != Product.Status.DOWNLOADING && status != Product.Status.WAITING) {
                Logger.info("resuming download of "+title);
                verify(product);
            }

            else {
                Logger.info(title+" is already downloading");
            }
        }
    }

    private void retry(Product product) {

        String id = product.getIdentifier();
        String title = product.getTitle();

        int numTries = tries.get(id);

        product.setStatus(Product.Status.PURCHASED);

        //if we haven't already tried the max number of times, do it again

        if (tries.get(id) < MAX_TRIES) {
            tries.put(id, numTries+1);
            Logger.info("Retrying download of "+title);
            verify(product);
        }

        //otherwise, it will remain in the pending products store and we'll re-attempt this next time the inventory loads

        else {
            Logger.info(String.format("Already tried downloading %s %d times, giving up for now", title, MAX_TRIES));

            PurchaseNotificationInfo info = notificationController.get(id);
            info.setNotificationType(NotificationType.DOWNLOAD_FAILED);
            notificationController.removePurchaseNotification(id);

            tries.remove(id);

            IAPEventListener listener = IAPManager.shared().getEventListener();
            if (listener != null) {
                listener.downloadFailed(product);
            }
        }

    }

    private void verify(final Product product) {

        final String id = product.getIdentifier();
        final String title = product.getTitle();

        product.setStatus(Product.Status.WAITING);

        if(!notificationController.contains(id))
            notificationController.registerPurchaseNotification(id, title, NotificationType.VERIFYING_RECEIPT);

        if(!tries.containsKey(id))
            tries.put(id, 1);

        AppAuthenticatedRequest verifyRequest = new AppAuthenticatedRequest ("POST", product.getDownloadURLString() + "?platform=android");

        Receipt receipt = Receipt.fetch(id);
        String raw_receipt = receipt.getSignedData();
        String signature = receipt.getSignature();

        //these will only be present for paid products, otherwise we'll just send the bare request
        if (raw_receipt != null && signature != null) {

            Logger.debug("paid product, verifying receipt");
            Logger.debug("receipt: "+raw_receipt+" signature: "+signature);

            //set the post body to the raw receipt string, with json content type
            try {
                StringEntity entity;
                entity = new StringEntity(raw_receipt, HTTP.UTF_8);
                entity.setContentType("application/json");
                verifyRequest.setEntity(entity);
            } catch (UnsupportedEncodingException e) {
                Logger.error("Error setting verifyRequest entity");
            }

            //put the signature in the header
            BasicHeader signatureHeader = new BasicHeader("x-google-iap-signature", signature);
            verifyRequest.addHeader(signatureHeader);
        }

        else {
            Logger.debug("free product, sending bare request");
        }

        queue.addRequest(verifyRequest, new AsyncHandler() {

            public void onComplete(Response response) {

                String responseString = response.body();
                Logger.verbose("verifyRequest result " + responseString);

                JSONObject jsonObject;

                if (response.status() == 200) {

                    try{
                        jsonObject = (JSONObject) new JSONTokener(responseString).nextValue();
                        String contentURLString = jsonObject.getString("content_url");
                        download(product, contentURLString);
                    }
                    catch(Exception e) {
                        Logger.error("Error parsing verification response from server, for product "+title);
                        retry(product);
                    }
                }

                else {
                    Logger.debug("verifyRequest response status: "+response.status());
                    retry(product);

                }


            }

            public void onError(Exception e) {
                Logger.error("Error fetching content url from server, for product: "+product);
                retry(product);
            }
        });

        PurchaseNotificationInfo info = notificationController.get(id);
        notificationController.sendNotification(info);

        IAPEventListener listener = IAPManager.shared().getEventListener();
        if (listener != null) {
            listener.downloadStarted(product, tries.get(id));
        }
    }

    private void download(final Product product, final String contentURLString) {

        final String id = product.getIdentifier();
        final String title = product.getTitle();

        //use the product id as our directory name for download/extraction
        //but make sure it's a legal directory name first
        String directoryName = sanitize(id);


        Request downloadRequest = new Request("GET", contentURLString);
        product.setStatus(Product.Status.DOWNLOADING);

        PurchaseNotificationInfo info = notificationController.get(id);
        info.setNotificationType(NotificationType.DOWNLOADING);
        notificationController.sendNotification(info);

        try {

            //everything will get glommed onto here
            File basePath;

            //is the SD card available for writing?
            if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {

                //SD card is mounted with read-write access
                basePath = Environment.getExternalStorageDirectory();
                Logger.debug("Writing to SD card");
            }

            else {
                //either SD card is not mounted, is read-only, or something else is awry
                //use internal storage instead
                basePath = UAirship.shared().getApplicationContext().getFilesDir();
                Logger.info("SD card not available, writing to internal storage");
            }


            final File tempFile = new File(basePath, IAPManager.shared().getTempPath() + directoryName + ".zip").getCanonicalFile();
            final File downloadPath = new File(basePath, IAPManager.shared().getDownloadPath() + directoryName).getCanonicalFile();

            downloadRequest.setDestination(tempFile);

            queue.addRequest(downloadRequest, new AsyncHandler(){

                @Override
                public void onComplete(Response response) {
                    Logger.info("Downloaded product to "+tempFile+", extracting...");

                    PurchaseNotificationInfo info = notificationController.get(id);

                    //this covers the edge case where the file is small enough that download progress wasn't reported
                    //although in replacing it with the spinner, I'm not sure this will actually have any noticeable effect...
                    info.setProgress(100);

                    IAPEventListener listener = IAPManager.shared().getEventListener();
                    if (listener != null) {
                        listener.downloadProgress(product, 100);
                    }

                    info.setNotificationType(NotificationType.DECOMPRESSING);

                    notificationController.sendNotification(info);

                    //extract the archive asynchronously
                    UnzipperTask task = new UnzipperTask();
                    task.setDelegate(new UnzipDelegate(product, downloadPath));

                    task.execute(tempFile, downloadPath);

                }

                @Override
                public void onError(Exception e) {
                    Logger.error("Download " + product + " failed", e);
                    retry(product);
                }

                @Override
                public void onProgress(int progress) {
                    Logger.verbose("Download " + product + " progress " + progress);

                    //update download notification with progress
                    PurchaseNotificationInfo info = notificationController.get(id);
                    info.setProgress(progress);
                    notificationController.sendNotification(info);

                    IAPEventListener listener = IAPManager.shared().getEventListener();
                    if (listener != null) {
                        listener.downloadProgress(product, progress);
                    }
                }
            });

        }

        catch(Exception e) {
            Logger.error("Error downloading product "+title, e);
            retry(product);
        }

    }

    private String sanitize(String directoryName) {
        //trim leading and trailing whitespace
        String result = directoryName.trim();

        //delete any trailing non-alphanumeric characters
        while(!(result.substring(result.length()-1).matches("[a-zA-Z0-9]"))) {
            result = result.substring(0, result.length()-1);
        }

        return result;
    }

    private class UnzipDelegate extends UnzipperTask.Delegate {

        Product product;
        File downloadPath;

        public UnzipDelegate(Product product, File downloadPath) {
            super();
            this.product = product;
            this.downloadPath = downloadPath;
        }

        @Override
        public void onSuccess() {
            //update notification with success message

            String id = product.getIdentifier();
            PurchaseNotificationInfo info = notificationController.get(id);

            info.setNotificationType(NotificationType.INSTALL_SUCCESSFUL);

            product.setStatus(Product.Status.INSTALLED);
            product.setDownloadPath(downloadPath);

            Logger.verbose("Setting download path for "+info.getProductName()+": "+downloadPath);

            //write the download path to disk
            Receipt receipt = Receipt.fetch(product.getIdentifier());
            receipt.setDownloadPathString(downloadPath.toString());
            receipt.serialize();

            notificationController.removePurchaseNotification(id);
            removePendingProduct(id);
            tries.remove(id);

            IAPEventListener listener = IAPManager.shared().getEventListener();
            if (listener != null) {
                listener.downloadSuccessful(product);
            }
        }

        @Override
        public void onFail(Exception error) {

            String id = product.getIdentifier();
            String title = product.getTitle();

            String failString = String.format("Extraction of %s failed", title);
            Logger.error(failString, error);

            //update notification with failure message
            PurchaseNotificationInfo info = notificationController.get(id);
            info.setNotificationType(NotificationType.DECOMPRESS_FAILED);
            notificationController.sendNotification(info);

            retry(product);
        }

        @Override
        public void onProgressUpdate(int progress) {
            //update notification with extraction progress
            //(is this really necessary?)
        }
    }

    private class InventoryObserver implements Observer {

        public void update (Observable o, Object arg) {
            Inventory.Status status = ((Inventory) arg).getStatus();
            if (status == Inventory.Status.LOADED) {

                if (IAPManager.isFirstRun() && IAPManager.isBillingSupported()) {
                    IAPManager.shared().restoreTransactions();
                }

                else {
                    resumePendingProducts();
                }
            }
        }

    }
}
