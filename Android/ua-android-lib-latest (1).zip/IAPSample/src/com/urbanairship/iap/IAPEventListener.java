/*
Copyright 2009-2012 Urban Airship Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE URBAN AIRSHIP INC ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL URBAN AIRSHIP INC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.urbanairship.iap;

/**
 * Abstract class used to respond to event callbacks from IAP.
 * 
 */
public abstract class IAPEventListener {

    /**
     * Called when IAP is restoring previous transactions.
     */
    public abstract void restoreStarted();
    /**
     * Called when a product download has failed.
     * @param p The product that failed to download.
     */
    public abstract void downloadFailed(Product p);
    /**
     * Called periodically with download progress for a particular product.
     * @param p The product being downloaded.
     * @param progress The current download progress as an integer between 0-100 inclusive
     */
    public abstract void downloadProgress(Product p, int progress);
    /**
     * Called if the download of a particular product succeeded.
     * @param p The product that was downloaded.
     */
    public abstract void downloadSuccessful(Product p);
    /**
     * Called when a product download begins.
     * @param p The product being downloaded.
     * @param attempt An integer representing the number times the download has been attempted.
     */
    public abstract void downloadStarted(Product p, int attempt);
    /**
     * Called if Android Market is currently unavailable on the device.
     * @param p The product the user is attempting to purchase.
     */
    public abstract void marketUnavailable(Product p);
    /**
     * Called when the availability of in-app billing is determined.
     * @param b A boolean representing whether in-app billing is currently supported on the installed version of Android Market.
     */
    public abstract void billingSupported(boolean b);
}
