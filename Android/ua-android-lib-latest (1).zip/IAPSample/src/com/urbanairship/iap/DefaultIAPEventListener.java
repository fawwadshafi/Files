/*
Copyright 2009-2012 Urban Airship Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE URBAN AIRSHIP INC ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL URBAN AIRSHIP INC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.urbanairship.iap;

import com.urbanairship.Logger;
import com.urbanairship.util.Toaster;

/**
 * A default concrete subclass of IAPEventListener, displaying toasts and log statements in response to IAP events.
 */
public class DefaultIAPEventListener extends IAPEventListener {

    @Override
    public void restoreStarted() {
        Toaster.simpleToast("Checking for existing purchases");
    }

    @Override
    public void downloadFailed(Product p) {
        String failString = String.format("Download of %s failed", p.getTitle());
        Toaster.simpleToast(failString);
    }

    @Override
    public void downloadSuccessful(Product p) {
        String successString = p.getTitle()+" was sucessfully installed";
        Toaster.simpleToast(successString);
    }

    @Override
    public void downloadStarted(Product p, int attempt) {
        //only display the toast if it's our first try so as not to be annoying
        if (attempt == 1) {
            Toaster.simpleToast(String.format("Downloading %s...", p.getTitle()));
        }
    }

    @Override
    public void marketUnavailable(Product p) {
        Toaster.longerToast("Error connecting to billing service, please try again later");
    }

    @Override
    public void downloadProgress(Product p, int progress) {
        Logger.verbose("Download progress for "+p.getTitle()+": "+progress+"%");
    }

    @Override
    public void billingSupported(boolean supported) {
        if(!supported)
            Toaster.longerToast("Billing is not supported on this version of Android Market");
    }

}
