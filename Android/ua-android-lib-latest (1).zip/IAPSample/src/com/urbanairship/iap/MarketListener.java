/*
Copyright 2009-2012 Urban Airship Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE URBAN AIRSHIP INC ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL URBAN AIRSHIP INC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.urbanairship.iap;

import android.os.Handler;

import com.urbanairship.Logger;
import com.urbanairship.iap.marketinterface.AbstractMarketListener;
import com.urbanairship.iap.marketinterface.BillingService.RequestPurchase;
import com.urbanairship.iap.marketinterface.BillingService.RestoreTransactions;
import com.urbanairship.iap.marketinterface.Consts.PurchaseState;
import com.urbanairship.iap.marketinterface.Consts.ResponseCode;

/**
 * Listener class used by IAP to respond to events from the Market billing service.
 *
 */
public class MarketListener extends AbstractMarketListener {

    public MarketListener(Handler handler) {
        super(handler);
    }

    @Override
    public void onBillingSupported(boolean supported) {
        IAPManager.onBillingSupported(supported);
    }

    @Override
    public void onPurchaseStateChange(PurchaseState purchaseState,
            String itemId, int quantity, long purchaseTime,
            String developerPayload) {
        //nothing to do...should probably modify PurchaseObserver so it doesn't complain about this one missing
    }

    @Override
    public void onRequestPurchaseResponse(RequestPurchase request,
            ResponseCode responseCode) {

        if (responseCode != ResponseCode.RESULT_OK) {
            Product product = IAPManager.shared().getInventory().getProduct(request.mProductId);
            product.setStatus(Product.Status.UNPURCHASED);
        }

    }

    @Override
    public void onRestoreTransactionsResponse(RestoreTransactions request,
            ResponseCode responseCode) {

        if (responseCode == ResponseCode.RESULT_OK) {
            Logger.info("OK response from onRestoreTransactionsRequest, calling firstRun()");
            IAPManager.firstRun();
        }
    }

    //our custom onPurchaseStateChange that takes the data we actually care about
    public void onPurchaseStateChange(final PurchaseState purchaseState, final String productId, final String orderId,
            final long purchaseTime, final String signedData, final String signature) {

        Logger.info("purchase state changed for "+productId + ": "+purchaseState);

        if(purchaseState == PurchaseState.PURCHASED) {

            Product product = IAPManager.shared().getInventory().getProduct(productId);

            if (product != null) {

                //store purchase receipt --
                //note that we're passing the product revision here from our own inventory
                Logger.info("storing purchase receipt for " +productId);
                Receipt receipt = new Receipt(product.getRevision(), productId, orderId, purchaseTime, signedData, signature);
                receipt.serialize();

                //initiate download
                Logger.info("starting download for " +productId);
                IAPManager.shared().getDownloadManager().downloadIfValid(product);
            }

            else {
                Logger.warn("Couldn't find product id "+productId+" in inventory!");
            }
        }

    }

}
