/*
Copyright 2009-2012 Urban Airship Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE URBAN AIRSHIP INC ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL URBAN AIRSHIP INC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.urbanairship.iap;

import android.app.Notification;

import com.urbanairship.util.NotificationIDGenerator;

/**
 * Wrapper class for details associated with purchase notifications.
 *
 */
public class PurchaseNotificationInfo {

    /**
     * The type of notification being triggered, corresponding to the product download sequence.
     */
    public enum NotificationType {
        /**
         * The product download has failed.
         */
        DOWNLOAD_FAILED,
        /**
         * The product download succeeded but failed to decompress.
         */
        DECOMPRESS_FAILED,
        /**
         * The product has started downloading.
         */
        DOWNLOADING,
        /**
         * The product has finished downloading and is being decompressed.
         */
        DECOMPRESSING,
        /**
         * The product was successfully installed.
         */
        INSTALL_SUCCESSFUL,
        /**
         * IAP is verifying the product's purchase receipt.
         */
        VERIFYING_RECEIPT
    }

    private NotificationType type;
    private String productName; // The product name
    private String productId; //The product Id

    private int notificationId;
    private int flags; //Bitfield holding Android Notification flags
    private int progress = 0;//The current progress position, range 0-100 inclusive
    private long timestamp;

    /**
     * Getter for the wrapper's notification type.
     * @return A NotificationType enum constant.
     */
    public NotificationType getNotificationType() {
        return type;
    }

    /**
     * Getter for the product name associated with the wrapper.
     * @return The product's name as a String.
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Getter for the product identifier associated with the wrapper.
     * @return The product's identifier as a String.
     */
    public String getProductId() {
        return productId;
    }

    /**
     * Getter for the notification identifier to be used when building notifications.
     * @return The notification identifier as an integer.
     */
    public int getNotificationId() {
        return notificationId;
    }

    /**
     * Getter for the bitfield to be used when building notifications.
     * @return The notification flags as an integer.
     */
    public int getFlags() {
        return flags;
    }

    /**
     * Getter for the current download progress of the product associated with the wrapper.
     * @return The product's download progress as an integer between 0-100.
     */
    public int getProgress() {
        return progress;
    }

    /**
     * Getter for the timestamp to be used when building notifications.
     * @return The timestamp as a long.
     */
    public long getTimestamp() {
        return timestamp;
    }

    /**
     * Setter for the wrapper's notification type.
     * @param type A NotificationType enum constant.
     */
    public void setNotificationType(NotificationType type) {
        this.type = type;
    }

    /**
     * Setter for the product name associated with the wrapper.
     * @param productName The product's name as a String.
     */
    public void setProductName(String productName) {
        this.productName = productName;
    }

    /**
     * Setter for the product identifier associated with the wrapper.
     * @param productId A product identifier String
     */
    public void setProductId(String productId) {
        this.productId = productId;
    }

    /**
     * Setter for the notification identifier to be used when building notifications.
     * @param notificationId A unique notification identifier integer.
     */
    public void setNotificationId(int notificationId) {
        this.notificationId = notificationId;
    }

    /**
     * Setter for the current download progress of the product associated with the wrapper.
     * @param progress The product's download progress as an integer between 0-100.
     */
    public void setProgress(int progress) {
        this.progress = progress;
    }

    /**
     * Setter for the timestamp to be used when building notifications.
     * @param timestamp The timestamp as a long.
     */
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * Setter for the bitfield to be used when building notifications.
     * @param flags The notification flags as an integer
     */
    public void setFlags(int flags) {
        this.flags = flags;
    }

    /**
     * Constructs a new PurchaseNotificationInfo wrapper.
     * @param type A NotificationType enum constant.
     * @param theProductName A product name to associate with the wrapper.
     * @param theProductId A productId to associate with the wrapper.
     */
    public PurchaseNotificationInfo(NotificationType type, String theProductName, String theProductId) {
        this.type = type;
        productName = theProductName;
        productId = theProductId;

        notificationId = NotificationIDGenerator.nextID();

        //we want the default location of the notification to be the "ongoing" pane, until the download finishes (or fails)
        flags = Notification.FLAG_ONGOING_EVENT | Notification.FLAG_ONLY_ALERT_ONCE;

        timestamp = System.currentTimeMillis();
    }

}

