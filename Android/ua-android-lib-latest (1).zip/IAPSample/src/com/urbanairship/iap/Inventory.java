/*
Copyright 2009-2012 Urban Airship Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE URBAN AIRSHIP INC ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL URBAN AIRSHIP INC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.urbanairship.iap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;
import java.util.TreeMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.app.Activity;

import com.urbanairship.Logger;
import com.urbanairship.UAirship;
import com.urbanairship.restclient.AppAuthenticatedRequest;
import com.urbanairship.restclient.AsyncHandler;
import com.urbanairship.restclient.Response;

/**
 * IAP inventory data structure and interface.
 * 
 */
public class Inventory {

    /**
     * Inventory loading states.
     */
    public enum Status {
        /**
         * The inventory has been initialized.
         */
        INITIALIZED,

        /**
         * The inventory is currently downloading.
         */
        DOWNLOADING,

        /**
         * The inventory loaded successfully.
         */
        LOADED,

        /**
         * The inventory failed to initialize.
         */
        FAILED,

        /**
         * The inventory was initialized, but is empty
         */
        EMPTY
    };

    /**
     * The subsets of the inventory products can be filtered by.
     */
    public enum FilterType {
        /**
         * All products.
         */
        ALL,

        /**
         * All installed products.
         */
        INSTALLED,

        /**
         * All products with uninstalled updates.
         */
        UPDATED,
    };

    private Map<String, Product> products;
    private ArrayList<Product> allProducts;
    private ArrayList<Product> updatedProducts;
    private ArrayList<Product> installedProducts;

    private Status status;

    private InventoryObservable notifier;

    private class InventoryObservable extends Observable {
        public void notifyObservers(Object o) {
            setChanged();
            super.notifyObservers(o);
        }
    }

    Inventory() {
        super();

        // map keys in natural order
        products = new TreeMap<String, Product>();
        allProducts = new ArrayList<Product>();
        updatedProducts = new ArrayList<Product>();
        installedProducts = new ArrayList<Product>();

        status = Status.INITIALIZED;

        notifier = new InventoryObservable();
    }

    /**
     * Adds an observer to be notified with the inventory when its status changes.
     * @param o An object implementing the Observer interface.
     */
    public void addObserver(Observer o) {
        notifier.addObserver(o);
    }

    /**
     * Deletes an observer.
     * @param o An object implementing the Observer interface
     */
    public void deleteObserver(Observer o) {
        notifier.deleteObserver(o);
    }
    /**
     * Returns the inventory's loading state.
     * @return An {@link com.urbanairship.iap.Inventory.Status} enum.
     */
    public Status getStatus() {
        return status;
    }

    void setStatus(Status status) {
        this.status = status;
        notifier.notifyObservers(this);
    }

    /**
     * Returns a sorted and filtered list of products in the inventory.
     * @param type An {@link com.urbanairship.iap.Inventory.FilterType} enum.
     * @return a list of {@link com.urbanairship.iap.Product} instances
     */
    public List<Product> getProducts(FilterType type) {
        List<Product> list = null;
        switch (type) {
        case ALL:
            list = allProducts;
            break;
        case INSTALLED:
            list = installedProducts;
            break;
        case UPDATED:
            list = updatedProducts;
            break;
        default:
            Logger.error("No product list for " + type);
            break;
        }
        return Collections.unmodifiableList(list);
    }

    /**
     * Returns the number of products in the inventory, filtered by {@link com.urbanairship.iap.Inventory.FilterType}.
     * @param type An {@link com.urbanairship.iap.Inventory.FilterType} enum.
     * @return the number of products in the queried subset of the inventory as an integer.
     */
    public int size(FilterType type) {
        int size = 0;
        switch (type) {
        case ALL:
            size = allProducts.size();
            break;
        case INSTALLED:
            size = installedProducts.size();
            break;
        case UPDATED:
            size = updatedProducts.size();
            break;
        default:
            Logger.error("No product list for " + type);
            break;
        }
        return size;
    }

    /**
     * Returns a particular product, by identifier string.
     * @param productID A product identifier as a String.
     * @return A Product.
     */
    public Product getProduct(String productID) {
        return products.get(productID);
    }

    /**
     * Tests whether the inventory contains a particular product.
     * @param productID A product identifier as a String.
     * @return <code>true</code> if the product is in the inventory, <code>false</code> otherwise.
     */
    public boolean hasProduct(String productID) {
        return products.containsKey(productID);
    }

    // Refresh product list

    void refresh() {
        Logger.info("Updating inventory");

        allProducts.clear();
        allProducts.addAll(products.values());
        Collections.sort(allProducts); //sort in natural order(lexicographically by title)

        updatedProducts.clear();
        installedProducts.clear();

        for (Product product : allProducts) {
            if (product.getStatus() == Product.Status.UPDATE)
                updatedProducts.add(product);

            if (product.getStatus() == Product.Status.PURCHASED
                    || product.getStatus() == Product.Status.DOWNLOADING
                    || product.getStatus() == Product.Status.INSTALLED)
                installedProducts.add(product);
        }

        if(allProducts.size() > 0)
            setStatus(Status.LOADED);
        else
            setStatus(Status.EMPTY);
    }

    /**
     * Loads the inventory.
     */
    public void load() {
        if(!UAirship.shared().isFlying()) {
            throw new UnsupportedOperationException("Inventory cannot be loaded unless UAirship.takeOff() has been called");
        }

        Logger.info("Loading inventory");
        String url = UAirship.shared().getAirshipConfigOptions().hostURL;
        url += "api/app/content/?platform=android";
        Logger.info("Fetching inventory from: " + url);
        AppAuthenticatedRequest inventoryRequest = new AppAuthenticatedRequest("GET", url);

        inventoryRequest.executeAsync(new AsyncHandler() {

            public void onComplete(Response response) {

                if(response.status() == 200) {

                    String jsonString = response.body();
                    JSONArray jsonArray;

                    try {
                        Logger.info("Inventory response string: "+jsonString);
                        JSONTokener tokener = new JSONTokener(jsonString);
                        jsonArray = (JSONArray) tokener.nextValue();
                        setProducts(jsonArray);
                    }

                    catch(Exception e) {
                        Logger.error("Error parsing JSON product list");
                        setStatus(Status.FAILED);
                    }

                    refresh();

                    if(getStatus() == Status.LOADED)
                        Logger.info("Inventory loaded " + allProducts);
                }

                else {

                    if(response.status() == 401) {
                        Logger.error("Authorization failed, make sure the application key and secret are propertly set");
                    }

                    Logger.info("inventoryRequest response status: "+response.status());
                    Logger.info("inventoryRequest response string: "+response.body());
                    setStatus(Status.FAILED);
                }

            }

            public void onError(Exception e) {
                Logger.error("Error loading product inventory from server");
                setStatus(Status.FAILED);
            }
        });

        setStatus(Status.DOWNLOADING);
    }

    private void setProducts(JSONArray jsonArray) throws JSONException {
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject object = jsonArray.getJSONObject(i);
            Product product = new Product(object);
            products.put(product.getIdentifier(), product);
        }
    }

    // Purchase and download
    void purchase(Activity activity, String productID) {
        purchase(activity, getProduct(productID));
    }

    /**
     * Initiates a purchase.
     * @param activity The activity initiating the purchase.
     * @param product The product being purchased.
     */
    public void purchase(Activity activity, Product product) {

        String id = product.getIdentifier();
        String title = product.getTitle();

        if (this.status != Status.LOADED) {
            return;
        }

        Logger.info("Retrieving product: " + title);

        if (product.isFree() == true || product.getStatus() == Product.Status.UPDATE) {
            Logger.info("Free or updated product, will download if valid...");

            if(Receipt.contains(product.getIdentifier())) {
                //update the existing receipt with the new revision number
                Receipt receipt = Receipt.fetch(id);
                receipt.setProductRevision(product.getRevision());
                receipt.serialize();
            }

            else {
                //store a stripped-down purchase receipt we can check against later
                Receipt receipt = new Receipt(product.getRevision(), product.getIdentifier());
                receipt.serialize();
            }

            IAPManager.shared().getDownloadManager().downloadIfValid(product);

        } else {
            if(activity != null) {
                Logger.info("Paid product, attempting to purchase: [" + product.getIdentifier() + "] " + product.getTitle());
                product.setStatus(Product.Status.WAITING);
                if(!IAPManager.shared().payForProduct(activity, product))
                    product.setStatus(Product.Status.UNPURCHASED);
            }
            else {
                Logger.warn("Attempting to purchase product with null activity parameter, bailing");
            }
        }
    }
    //TODO use?
    /*
    private void downloadAllUpdates(Context context) {
        if (this.status != Status.LOADED)
            return;

        Logger.info("Updating " + size(FilterType.UPDATED) + " products");
        for (Product product : getProducts(FilterType.UPDATED)) {
            purchase(null, product);
        }
    } */
}
