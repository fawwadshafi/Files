/*
Copyright 2009-2012 Urban Airship Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE URBAN AIRSHIP INC ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL URBAN AIRSHIP INC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.urbanairship.iap;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Handler;

import com.urbanairship.Logger;
import com.urbanairship.UAirship;
import com.urbanairship.iap.marketinterface.BillingReceiver;
import com.urbanairship.iap.marketinterface.BillingService;
import com.urbanairship.iap.marketinterface.ResponseHandler;

/**
 * This class is the primary interface for customizing the behavior of IAP.
 * 
 */
public final class IAPManager {

    //Constants

    private static final String IAP_FIRST_RUN_PREFERENCES = "com.urbanairship.iap.first_run";
    private static final String INITIALIZED_KEY =  "initialized";

    //Singleton instance
    private static final IAPManager instance = new IAPManager();

    //Singleton fields
    private Inventory inventory;
    private String appName = null;
    private int appIcon;
    private DownloadManager downloadManager;
    private BillingService billingService;
    private MarketListener marketListener;

    private PurchaseNotificationBuilder notificationBuilder;

    private boolean isBillingSupported = false;

    private String tempPath;
    private String downloadPath;

    private IAPEventListener eventListener;

    private IAPManager() {
    }

    /**
     * Getter for the IAPManager singleton instance.
     * @return The shared IAPManager instance.
     */
    public static IAPManager shared() {
        return instance;
    }

    /**
     * Initializes IAP.  Ordinarily called by {@link com.urbanairship.UAirship} on take off.
     * <code>UAirship.takeOff()</code> MUST be called before this method is invoked.
     */
    public static void init() {

        instance.inventory = new Inventory();
        instance.downloadManager = new DownloadManager();
        instance.notificationBuilder = new BasicPurchaseNotificationBuilder();

        instance.billingService = new BillingService();
        instance.billingService.setContext(UAirship.shared().getApplicationContext());
        instance.appName = UAirship.getAppName();
        instance.appIcon = UAirship.getAppIcon();

        instance.billingService.checkBillingSupported();

        instance.eventListener = new DefaultIAPEventListener();

        if(instance.marketListener != null)
            ResponseHandler.unregister(instance.marketListener);

        instance.marketListener = new MarketListener(new Handler());

        ResponseHandler.register(instance.marketListener);
    }

    /**
     * Shuts down IAP services.
     */
    public static void tearDown() {
        instance.billingService.unbind();
        ResponseHandler.unregister(instance.marketListener);
    }

    /**
     * Indicates whether billing is supported on the currently installed version of Android Market.
     * @return <code>true</code> if billing is supported, <code>false</code> otherwise.
     */
    public static boolean isBillingSupported() {
        return instance.isBillingSupported;
    }

    //called by MarketListener
    static void onBillingSupported(boolean supported) {
        instance.isBillingSupported = supported;
        if (instance.eventListener != null) {
            instance.eventListener.billingSupported(supported);
        }

    }

    //called by MarketListener
    static void firstRun() {

        Context appContext = UAirship.shared().getApplicationContext();
        SharedPreferences preferences = appContext.getSharedPreferences(IAP_FIRST_RUN_PREFERENCES, Context.MODE_PRIVATE);

        try {
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean(INITIALIZED_KEY, true);
            editor.commit();
        }
        catch(Exception e) {
            Logger.error("Error writing to shared preferences");
        }
    }

    static boolean isFirstRun() {
        Context appContext = UAirship.shared().getApplicationContext();
        SharedPreferences preferences = appContext.getSharedPreferences(IAP_FIRST_RUN_PREFERENCES, Context.MODE_PRIVATE);
        boolean initialized = preferences.getBoolean(INITIALIZED_KEY, false);
        return !initialized;
    }

    /**
     * Returns the IAP inventory.
     * @return An instance of the Inventory class.
     */
    public Inventory getInventory() {
        return inventory;
    }

    /**
     * Returns the application's name.
     * @return The app name as a String.
     */
    public String getAppName() {
        return appName;
    }

    /**
     * Returns the application's icon.
     * @return The app icon's drawable id.
     */
    public int getAppIcon() {
        return appIcon;
    }

    DownloadManager getDownloadManager() {
        return downloadManager;
    }

    BillingService getBillingService() {
        return billingService;
    }

    /**
     * Sets the notification builder used for creating purchase notifications.
     * @param builder An object implementing the PurchaseNotificationBuilder interface.
     */
    public void setNotificationBuilder(PurchaseNotificationBuilder builder) {
        notificationBuilder = builder;
    }

    /**
     * Returns the notification builder used for creating purchase notifications.
     * @return An object implementing the PurchaseNotificationBuilder interface.
     */
    public PurchaseNotificationBuilder getNotificationBuilder() {
        return notificationBuilder;
    }

    /**
     * Returns the relative path where compressed product downloads are stored prior to extraction.
     * @return A relative path as a String.
     */

    public String getTempPath() {
        if(tempPath != null)
            return tempPath;
        else
            return "iap/temp/"+UAirship.getAppName()+"/";
    }

    /**
     * Returns the relative path where extracted product downloads are stored.
     * @return A relative path as a String.
     */
    public String getDownloadPath() {
        if(downloadPath != null)
            return downloadPath;
        else
            return "iap/downloads/"+UAirship.getAppName()+"/";
    }

    /**
     * Returns the relative path where compressed product downloads are stored prior to extraction.
     * @param path A relative path as a String.
     */
    public void setTempPath(String path) {
        tempPath = path;
    }

    /**
     * Sets the relative path where extracted product downloads are stored.
     * @param path A relative path as a String.
     */
    public void setDownloadPath(String path) {
        downloadPath = path;
    }

    /**
     * Sets the listener used to respond to IAP events.
     * @param eventListener A concrete subclass of IAPEventListener.
     */
    public void setEventListener(IAPEventListener eventListener) {
        this.eventListener = eventListener;
    }

    /**
     * Returns the listener used to respond to IAP events.
     * @return A concrete subclass of IAPEventListener.
     */
    public IAPEventListener getEventListener() {
        return eventListener;
    }


    /**
     * Restores previously purchased items.  This should only be called in the case
     * where an item has already been purchased but needs to be re-downloaded.  Calling
     * this method will cause the app to re-download all existing purchases.  This method
     * is automatically called by the library on first run.
     */
    public void restoreTransactions() {
        IAPEventListener listener = getEventListener();
        if (listener != null) {
            listener.restoreStarted();
        }
        getBillingService().restoreTransactions();
    }

    boolean payForProduct(Activity context, Product product) {
        if(isBillingSupported) {
            if (!billingService.requestPurchase(context, product.getIdentifier())) {
                if (this.eventListener != null) {
                    eventListener.marketUnavailable(product);
                }
                return false;
            }
        }

        else {
            Logger.error("Billing is not supported on this version of Android Market");
            return false;
        }

        return true;
    }

    public static void validateManifest() {

        PackageManager pm = UAirship.getPackageManager();

        // check for billing receiver
        ComponentName billingReceiver = new ComponentName(UAirship.getPackageName(),
                BillingReceiver.class.getCanonicalName());
        try {
            pm.getReceiverInfo(billingReceiver, PackageManager.GET_META_DATA);

            //check for IN_APP_NOTIFY intent
            Intent i = new Intent("com.android.vending.billing.IN_APP_NOTIFY");
            if (pm.queryBroadcastReceivers(i, 0).isEmpty()) {
                Logger.error("AndroidManifest.xml's "+BillingReceiver.class.getCanonicalName()+" declaration missing required "+i.getAction()+" filter");
            }

            //check for RESPONSE_CODE intent
            i = new Intent("com.android.vending.billing.RESPONSE_CODE");
            if (pm.queryBroadcastReceivers(i, 0).isEmpty()) {
                Logger.error("AndroidManifest.xml's "+BillingReceiver.class.getCanonicalName()+" declaration missing required "+i.getAction()+" filter");
            }

            //check for PURCHASE_STATE_CHANGED intent
            i = new Intent("com.android.vending.billing.PURCHASE_STATE_CHANGED");
            if (pm.queryBroadcastReceivers(i, 0).isEmpty()) {
                Logger.error("AndroidManifest.xml's "+BillingReceiver.class.getCanonicalName()+" declaration missing required "+i.getAction()+" filter");
            }

        } catch (NameNotFoundException e) {
            Logger.error("AndroidManifest.xml missing required receiver: " + BillingReceiver.class.getCanonicalName());
        }

        // check for billing service
        ComponentName billingService = new ComponentName(UAirship.getPackageName(),
                BillingService.class.getCanonicalName());
        try {
            pm.getServiceInfo(billingService, PackageManager.GET_META_DATA);
        } catch (NameNotFoundException e) {
            Logger.error("AndroidManifest.xml missing required service: " + BillingService.class.getCanonicalName());
        }

        //check for billing permission
        checkRequiredPermission("com.android.vending.BILLING");

    }

    private static void checkRequiredPermission(String permission) {
        PackageManager pm = UAirship.getPackageManager();
        if (PackageManager.PERMISSION_DENIED == pm.checkPermission(permission, UAirship.getPackageName())) {
            Logger.error("AndroidManifest.xml missing required IAP permission: " + permission);
        }
    }

}
