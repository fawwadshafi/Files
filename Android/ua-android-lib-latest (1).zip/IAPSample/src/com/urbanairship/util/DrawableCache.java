/*
Copyright 2009-2012 Urban Airship Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE URBAN AIRSHIP INC ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL URBAN AIRSHIP INC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.urbanairship.util;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import android.graphics.drawable.Drawable;

import com.urbanairship.Logger;

public class DrawableCache {

    private int currentSize;
    private int maxSize;
    private final Map<String, Drawable> drawableMap;

    public DrawableCache(int size) {
        this.drawableMap = Collections.synchronizedMap(new LRUCache<String, Drawable>(20, 0.75f));
        setMaxSize(size);
    }

    public void setMaxSize(int size) {
        this.maxSize = size;
    }

    public Drawable put(String k, Drawable d) {
        drawableMap.put(k, d);
        housekeeping();
        return d;
    }

    public Drawable get(String k) {
        return drawableMap.get(k);
    }

    public boolean containsKey(String k) {
        return drawableMap.containsKey(k);
    }

    public Drawable remove(String k) {
        return drawableMap.remove(k);
    }

    private int estimatedSize(Drawable d) {
        int w = d.getIntrinsicWidth();
        int h = d.getIntrinsicHeight();

        //theoretically possible but unlikely edge case
        if (w<0 || h <0) {
            return 0;
        } else {
            //assuming 32-bit depth, conservatively
            return w * h * 4;
        }
    }

    private void housekeeping() {
        if (currentSize > maxSize) {
            Logger.verbose("DrawableCache: purge");
            Set<Map.Entry<String, Drawable>> s = drawableMap.entrySet();
            synchronized(drawableMap) {
                Iterator<Map.Entry<String, Drawable>> i = s.iterator(); // Must be in synchronized block
                while (i.hasNext() && currentSize > maxSize) {
                    Map.Entry<String, Drawable> entry = i.next();
                    Logger.verbose("DrawableCache: removing "+entry.getKey());
                    i.remove();
                }
            }
        }
    }

    private void incrementSizeBy(Object value) {
        currentSize += estimatedSize((Drawable)value);
        Logger.verbose("DrawableCache increment: ~"+currentSize+" bytes");
    }

    private void decrementSizeBy(Object value) {
        currentSize -= estimatedSize((Drawable)value);
        Logger.verbose("DrawableCache decrement: ~"+currentSize+" bytes");
    }

    private class LRUCache<K, V> extends LinkedHashMap<K, V> {
        private static final long serialVersionUID = 1L;

        //note: size here refers to the number of entries
        public LRUCache(int size, float loadFactor) {
            //passing true as the third argument tells the LinkedHashMap
            //to order keys by access
            super(size, loadFactor, true);
        }

        @Override
        public V put(K key, V value) {
            incrementSizeBy(value);
            return super.put(key, value);
        }

        @Override
        public V remove(Object key) {
            V value = super.remove(key);
            decrementSizeBy(value);
            return value;
        }

        //we don't care about maintaining an upper bound on the number of
        //insertions, so much as memory load
        @Override
        protected boolean removeEldestEntry(final Map.Entry<K, V> eldest) {
            return false;
        }

    }

}
