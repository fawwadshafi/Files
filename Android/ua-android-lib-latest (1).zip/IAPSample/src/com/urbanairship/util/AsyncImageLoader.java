/*
Copyright 2009-2012 Urban Airship Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE URBAN AIRSHIP INC ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL URBAN AIRSHIP INC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*
 * Adapted from James A Wilson's version
 * From http://stackoverflow.com/questions/541966/android-how-do-i-do-a-lazy-load-of-images-in-listview
 */

package com.urbanairship.util;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;

import com.urbanairship.Logger;

/**
 * Provides asynchronous loading of image resources
 *
 */
public class AsyncImageLoader {

    private Delegate delegate;

    /**
     * Constructor
     *
     * @param urlString
     * @param delegate
     */
    public AsyncImageLoader(String urlString, Delegate delegate) {
        this.delegate = delegate;
        fetchDrawableOnThread(urlString);
    }

    public static abstract class Delegate {
        public abstract void imageLoaded(String urlString, Drawable imageDrawable);
    }

    private Drawable fetchDrawable(String urlString) {

        try {
            InputStream is = fetch(urlString);
            Drawable drawable = Drawable.createFromStream(is, "Async Image");
            return drawable;

        } catch (MalformedURLException e) {
            Logger.error("fetchDrawable failed", e);
            return null;

        } catch (IOException e) {
            Logger.error("fetchDrawable failed", e);
            return null;
        }
        catch (IllegalStateException e) {
            Logger.error("fetchDrawable failed", e);
            return null;
        }
    }

    private void fetchDrawableOnThread(final String urlString) {

        final Handler handler = new Handler() {
            @Override
            public void handleMessage(Message message) {
                Drawable drawable = (Drawable) message.obj;
                if(drawable != null)
                    delegate.imageLoaded(urlString, (Drawable) message.obj);
            }
        };

        Thread thread = new Thread() {
            @Override
            public void run() {
                Drawable drawable = fetchDrawable(urlString);
                Message message = handler.obtainMessage(1, drawable);
                handler.sendMessage(message);
            }
        };
        thread.start();
    }

    private InputStream fetch(String urlString) throws MalformedURLException,
    IOException, IllegalStateException {
        DefaultHttpClient httpClient = new DefaultHttpClient();
        HttpGet request = new HttpGet(urlString);
        HttpResponse response = httpClient.execute(request);
        return response.getEntity().getContent();
    }
}
