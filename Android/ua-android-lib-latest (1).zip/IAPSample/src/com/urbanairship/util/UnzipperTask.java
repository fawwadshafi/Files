/*
Copyright 2009-2012 Urban Airship Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE URBAN AIRSHIP INC ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL URBAN AIRSHIP INC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.urbanairship.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import android.os.AsyncTask;

import com.urbanairship.Logger;

public class UnzipperTask extends AsyncTask<File, Integer, Exception> {

    private Delegate delegate;

    @Override
    protected Exception doInBackground(File ... files) {

        File inputFile, basePath;

        if(files.length != 2)
            throw(new IllegalArgumentException());

        inputFile = files[0];
        basePath = files[1];

        try {
            ZipFile zipFile = new ZipFile(inputFile.getCanonicalPath());
            ArrayList<? extends ZipEntry> zippedFiles = Collections.list(zipFile
                    .entries());

            Logger.verbose("Zip file: " + zipFile.getName() + " contains "
                    + zippedFiles.size() + " files");


            for (ZipEntry zipEntry : zippedFiles) {

                long entrySize = zipEntry.getSize();
                if (entrySize == 0)
                    continue;

                String name = zipEntry.getName();
                Logger.info("Unzipping file entry: " + name);

                File outputFile = new File(basePath, name).getCanonicalFile();
                Logger.debug("Creating file "+outputFile);
                if(!outputFile.getParentFile().mkdirs()) {
                    Logger.debug("Couldn't create or didn't need to create "+outputFile.getParentFile());
                }
                outputFile.createNewFile();

                InputStream is = zipFile.getInputStream(zipEntry);
                FileOutputStream out = new FileOutputStream(outputFile);

                byte buf[] = new byte[4 * 1024];
                int count = 0;
                while ((count = is.read(buf)) > 0) {
                    out.write(buf, 0, count);
                }

                out.flush();

                is.close();
                out.close();
            }
        } catch(Exception e) {
            inputFile.delete();
            return e;
        }
        inputFile.delete();
        return null;
    }

    @Override
    protected void onProgressUpdate(Integer ... values) {
        delegate.onProgressUpdate(values[0]);
    }

    @Override
    protected void onPostExecute(Exception error) {
        if(error != null)
            delegate.onFail(error);
        else
            delegate.onSuccess();
    }

    public void setDelegate(Delegate delegate) {
        this.delegate = delegate;
    }

    public static abstract class Delegate {
        public abstract void onSuccess();
        public abstract void onFail(Exception error);
        public abstract void onProgressUpdate(int progress);
    }

}
